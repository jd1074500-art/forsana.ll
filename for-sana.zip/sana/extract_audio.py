"""Extract the audio track from a video.  Usage: python extract_audio.py [video] [output]
Requires ffmpeg: https://ffmpeg.org/download.html"""
import subprocess, sys
src = sys.argv[1] if len(sys.argv) > 1 else "assets/video.mp4"
dst = sys.argv[2] if len(sys.argv) > 2 else "assets/audio.mp3"
subprocess.run(["ffmpeg", "-y", "-i", src, "-vn", "-c:a", "libmp3lame", "-q:a", "2", dst], check=True)
print("Saved", dst)
