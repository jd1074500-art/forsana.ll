# For my love, Sana ♥

A small web page that plays a video (with sound), plays the audio on its own,
and shows **"For my love, Sana"** in 84 languages (rotating text, a heart made of the
phrases, and a searchable list).

## Run it locally
Just open `index.html` in a browser — or serve the folder:

    python -m http.server 8000      # then open http://localhost:8000

## Put it on GitHub (and get a live link)
1. Create a new repo on GitHub, e.g. `for-sana`.
2. Upload every file in this folder (keep the `assets/` folder).
   Or from a terminal:

       git init
       git add .
       git commit -m "For my love, Sana"
       git branch -M main
       git remote add origin https://github.com/YOUR-USERNAME/for-sana.git
       git push -u origin main

3. On GitHub: **Settings → Pages → Branch: main / (root) → Save**.
4. After a minute your page is live at `https://YOUR-USERNAME.github.io/for-sana/`

## Files
| File | What it does |
|---|---|
| `index.html`, `style.css`, `script.js` | The page |
| `phrases.js` | All the translations (generated) |
| `build_phrases.py` | Add/edit languages here, then run `python build_phrases.py` |
| `assets/video.mp4` | Your video |
| `assets/audio.mp3` | Audio extracted from the video |
| `extract_audio.py` | Re-extracts the audio from any video (needs ffmpeg) |

> Note: browsers block autoplay with sound, so the visitor taps the play button once.
> There are ~7,000 languages in the world, so "all" isn't possible — but you can add more in `build_phrases.py`.
> Please have native speakers check the translations of any language you plan to print or share widely.
