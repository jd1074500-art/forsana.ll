// ---------- rotating phrase ----------
const phraseEl = document.getElementById("phrase");
const langEl = document.getElementById("langName");
let i = 0;
function show() {
  const p = PHRASES[i % PHRASES.length];
  phraseEl.style.opacity = 0;
  setTimeout(() => {
    phraseEl.textContent = p.text;
    phraseEl.dir = p.rtl ? "rtl" : "ltr";
    langEl.textContent = p.lang;
    phraseEl.style.opacity = 1;
  }, 400);
  i++;
}
show(); setInterval(show, 2400);

// ---------- full list + search ----------
const list = document.getElementById("list");
document.getElementById("count").textContent = PHRASES.length;
function render(filter = "") {
  const f = filter.trim().toLowerCase();
  list.innerHTML = "";
  PHRASES.filter(p => !f || p.lang.toLowerCase().includes(f) || p.text.toLowerCase().includes(f))
    .forEach(p => {
      const li = document.createElement("li");
      const a = document.createElement("span"); a.textContent = p.lang;
      const b = document.createElement("span"); b.textContent = p.text; b.dir = p.rtl ? "rtl" : "ltr";
      li.append(a, b); list.append(li);
    });
}
render();
document.getElementById("search").addEventListener("input", e => render(e.target.value));

// ---------- video / audio (browsers need a tap before sound) ----------
const video = document.getElementById("video");
const audio = document.getElementById("audio");
const playBtn = document.getElementById("playBtn");
const audioBtn = document.getElementById("audioBtn");

playBtn.onclick = () => {
  audio.pause(); audioBtn.textContent = "🎧 Play audio only";
  video.muted = false;
  if (video.paused) { video.play(); playBtn.textContent = "⏸ Pause video"; }
  else { video.pause(); playBtn.textContent = "▶ Play video with sound"; }
};
audioBtn.onclick = () => {
  if (audio.paused) { video.pause(); playBtn.textContent = "▶ Play video with sound"; audio.play(); audioBtn.textContent = "⏸ Pause audio"; }
  else { audio.pause(); audioBtn.textContent = "🎧 Play audio only"; }
};

// ---------- heart made of the phrases ----------
(function drawHeart() {
  const c = document.getElementById("heart");
  const S = 520, dpr = window.devicePixelRatio || 1;
  c.width = S * dpr; c.height = S * dpr;
  const g = c.getContext("2d"); g.scale(dpr, dpr);
  const inHeart = (x, y) => { const a = x * x + y * y - 1; return a * a * a - x * x * y * y * y <= 0; };
  const colors = ["#ff4d8d", "#ff8fb8", "#ffd1e3", "#ffffff", "#ff6fa5"];
  let placed = 0, tries = 0;
  g.textAlign = "center"; g.textBaseline = "middle";
  while (placed < 420 && tries < 20000) {
    tries++;
    const hx = (Math.random() * 3 - 1.5), hy = (Math.random() * 3 - 1.5);
    if (!inHeart(hx, hy)) continue;
    const p = PHRASES[placed % PHRASES.length];
    const px = S / 2 + hx * S * 0.3, py = S / 2 - hy * S * 0.3 - 10;
    g.font = `${9 + Math.random() * 8}px "Noto Sans", system-ui, sans-serif`;
    g.fillStyle = colors[Math.floor(Math.random() * colors.length)];
    g.globalAlpha = 0.55 + Math.random() * 0.45;
    g.fillText(p.text, px, py);
    placed++;
  }
})();
